<?php
    cout(CMS_NAME . " v" . CMS_VERSION);

