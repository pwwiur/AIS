<?php
    cout("Usage: index.php [-h|--help] [-v|--version] [-r|--request request_value]");
    cout("  -h, --help: Display this help message.");
    cout("  -v, --version: Show script version.");
    cout("  -r, --request: Perform a request by a path.");

