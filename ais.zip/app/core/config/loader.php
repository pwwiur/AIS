<?php
    require __DIR__ . "/ais.php";
    require __DIR__ . "/switch.php";
    require __DIR__ . "/database.php";
    require __DIR__ . "/keys.php";
    require __DIR__ . "/micros.php";
    require __DIR__ . "/macros.php";
?>
