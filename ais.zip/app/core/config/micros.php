<?php
	const D = '.';
	const S = '/';
	const N = "\n";
	const R = "\r";
	const W = " ";
	const T = "\t";
	const Q = "?";
	const BR = "<br>";
	const PHP = D . 'php';
	const JSON = D . 'json';
	const TXT = D . 'txt';
?>
