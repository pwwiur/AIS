<?php
    const POWER = 1;
    const WRITE = 1;
    const DEBUG = 1;
?>