<?php
    const DBTYPE = "mysql";
    const DBSERVER =  "localhost";
    const DBCHARSET = "utf8";
    const DBNAME = "ais";
    const DBUSER = "ais_user";
    const DBUSERPASS = "PASSWORD";
?>
