<?php
    const CMS_NAME = "AIS";
    const CMS_VERSION = 6;
?>
