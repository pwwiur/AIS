<?php
    require __DIR__ . "/init.php";
    require __DIR__ . "/define.php";