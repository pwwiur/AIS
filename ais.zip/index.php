<?php
// +----------------------------------------------------------------------------+
// | AI web system (AIS) 4.01                                                   |
// +----------------------------------------------------------------------------+
// | Copyright (c) AFF 2019-2025. All rights reserved.                          |
// | Email         ----@------------.---                                        |
// | Web           ----------------.---                                         |
// | Version       1.01                                                         |
// | License       opensource.org/licenses/gpl-license.php GNU Public License   |
// | Product key   ad9870ww9d7ddaz9d0ad9900ddz10                                |
// +----------------------------------------------------------------------------+
// | An mvc based functional php framework, high security with high             |
// | processing speed.                                                          |
// |                                                                            |
// | This program is a free software; you can redistribute it and/or            |
// | modify it under the terms of the GNU General Public License                |
// | version 2 as published by the Software Foundation.                         |
// |                                                                            |
// | This program is distributed in the hope that it will be useful, but        |
// | WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY |
// | or FITNESS FOR A PARTICULAR PURPOSE.                                       |
// | See the GNU General Public License for more details.                       |
// |                                                                            |
// | You should have received a copy of the GNU General Public License along    |
// | with this program; if not, write to the                                    |
// | Free Software Foundation, Inc., 59 Temple Place, Suite 330,                |
// | Boston, MA 02111-1307 USA                                                  |
// |                                                                            |
// | Please give credit on sites that use AI system and submit changes of the   |
// | script so other people can use them as well.                               |
// |                                                                            |
// +----------------------------------------------------------------------------+

require __DIR__ . '/app/core/engine.php';
?>
